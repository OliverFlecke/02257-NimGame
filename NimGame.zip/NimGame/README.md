# Nim Game

The game of Nim written in F#.

## Files

Heaps.fs
AsyncEventQueue.fs
StateStore.fs
NimGameCmdUI.fs
NimGameGUI.fs
NimGame.fs

## Compile

To compile the program:

```cmd
fsc .\Heaps.fs .\AsyncEventQueue.fs .\StateStore.fs .\NimGameCmdUI.fs .\NimGameGUI.fs .\NimGame.fs
```

The executable `NimGame' will then be created and will execute the GUI client.
To use the command line view, specify the `-cli` argument.